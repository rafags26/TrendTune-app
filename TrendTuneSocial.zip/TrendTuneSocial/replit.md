# TrendTune

## Overview

TrendTune is a complete, fully functional neon-themed social media web application built with vanilla HTML, CSS, and JavaScript. It features a modern, cyberpunk-inspired design with gradient backgrounds, glowing effects, and animated equalizer logo. The application provides comprehensive social networking functionality including post creation with image upload, like/comment systems, content exploration with search and filters, profile management, follow systems, notifications, theme switching, and complete localStorage persistence.

**Status**: ✅ Production Ready - All features implemented and tested

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Pure Vanilla JavaScript**: No frameworks or libraries, using ES6+ features for modern functionality
- **Single Page Application (SPA)**: Tab-based navigation system with dynamic content switching
- **Component-Based Structure**: Modular approach with separate sections for feed, explore, notifications, and profile
- **CSS Custom Properties**: Centralized theming system using CSS variables for colors, spacing, and effects

### State Management
- **Global State Object**: Centralized state management using a single JavaScript object
- **LocalStorage Persistence**: All application data persists locally in the browser using localStorage
- **Helper Functions**: Simple DOM manipulation utilities (`$` for querySelector, `$$` for querySelectorAll)
- **Store Abstraction**: JSON-based localStorage wrapper for consistent data serialization

### User Interface Design
- **Neon Theme System**: Dark mode with vibrant neon colors (purple, cyan, green accents)
- **Responsive Design**: Mobile-first approach with flexible layouts
- **Visual Effects**: CSS animations, gradient backgrounds, glowing elements, and backdrop filters
- **Accessibility Features**: ARIA labels, semantic HTML, and keyboard navigation support

### Content Management
- **Post System**: Text-based posts with optional images, likes, and comments
- **Explore Section**: Curated content with categories (music, fashion, tech, lifestyle)
- **Notification System**: Toast notifications and persistent notification feed
- **Profile Management**: User profile with avatar, bio, and social stats

### Data Structure
- **Post Model**: ID, author info, text content, image URL, likes count, comments array
- **User Model**: Name, handle, bio, avatar, follower/following counts
- **Explore Content**: Categorized items with tags, titles, and images
- **Notifications**: Simple message-based notification system

## External Dependencies

### Image Services
- **Unsplash API**: Used for placeholder images in the explore section with automatic formatting and optimization parameters

### Fonts
- **Inter Font Family**: System fallback font stack including Inter, system-ui, and platform-specific fonts

### Browser APIs
- **LocalStorage**: Primary data persistence layer for all application state
- **Crypto API**: UUID generation for unique identifiers (crypto.randomUUID())
- **DOM APIs**: Standard browser APIs for element manipulation and event handling

### No External Frameworks
- The application intentionally avoids external JavaScript frameworks or CSS libraries
- All functionality is implemented using native web APIs and vanilla JavaScript
- Self-contained with no build process or package management required